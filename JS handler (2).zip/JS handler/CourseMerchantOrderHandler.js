/**
 * @NApiVersion 2.1
 */
define(['N/search', 'N/record', 'N/runtime'],
    
    (search, record, runtime) => {
        const handle = (salesOrder) => {
            const courseMerchantOrderHandler = new CourseMerchantSalesOrderHandler(salesOrder);
            courseMerchantOrderHandler.handle();
        }
        
        const CourseMerchantSalesOrderHandler = function(salesOrder){
            let keepProcessingTransactions = true;
            
            const originalCourseMerchantOrderId = salesOrder.getValue('custbody_cdg_cm_order_original_id'),
                courseMerchantOrderId = salesOrder.getValue('custbody_cdg_cm_order_id');
            const transactionsCreated = {
                salesOrder: {id: salesOrder.id}
            };
            
            const processingErrors = [];
            
            const handle = () => {
                if(_isOrderAmendment()){
                    log.audit('CourseMerchantOrderHandler', `Handling Order Amendment for CM Order [${courseMerchantOrderId}]`);
                    _handleOrderAmendment();
                } else {
                    log.audit('CourseMerchantOrderHandler', `Handling New CM Order [${courseMerchantOrderId}]`);
                    _handleOrder();
                }
                _maybePushOutErrors();
            }
            
            const _handleOrderAmendment = () => {
                const originalSalesOrderInternalId = _getOriginalSalesOrderInternalId();
                if(!originalSalesOrderInternalId){
                    _errorOutOriginalSalesOrderIdNotFound();
                } else {
                    const originalInvoiceId = _searchOriginalOrderInvoiceId(originalSalesOrderInternalId);
                    if (!originalInvoiceId) {
                         _errorOutOriginalInvoiceIdNotFound();
                     } else {
                        if (_isCancelationOrder()) {
                            log.audit('CourseMerchantOrderHandler', `Canceling CM Order [${courseMerchantOrderId}]`);
                            _cancelOriginalOrder(originalInvoiceId);
                            _cancelSalesOrder();
                        } else {
                            log.audit('CourseMerchantOrderHandler', `Creating Amendement Transactions for CM Order [${courseMerchantOrderId}]`);
                            _createAmendmentTransactions(originalInvoiceId);
                        }
                    }
                }
            }
            
            const _createAmendmentTransactions = (originalInvoiceId) => {
                _createReturnAuthorization(originalInvoiceId);
                if(keepProcessingTransactions) {
                    if(_originalInvoiceShouldBeClosed(originalInvoiceId)) {
                        _createCreditMemoWithOriginalInvoiceApplied(originalInvoiceId);
                    }
                }
                if(keepProcessingTransactions){
                    _createInvoice();
                }
                if(keepProcessingTransactions){
                    if(_customerPaymentIsRequired()) {
                        _createCreditMemo();
                        _createCustomerPaymentWithCreditAndNewInvoiceApplied();
                    } else{
                        _createCreditMemoWithNewInvoiceApplied();
                    }
                }
            }
            
            const _cancelOriginalOrder = (originalInvoiceId) => {
                _createReturnAuthorization(originalInvoiceId);
                if(keepProcessingTransactions) {
                    if(_customerPaymentIsRequired()) {
                        _createCreditMemo();
                    } else{
                        _createCreditMemoWithOriginalInvoiceApplied(originalInvoiceId);
                    }
                }
            }
            
            const _handleOrder = () => {
                _createInvoice();
                if (_customerPaymentIsRequired() && keepProcessingTransactions) {
                    _createCustomerPayment();
                }
            }
        
            const _createInvoice = () => {
                log.audit('CourseMerchantOrderHandler', `Creating Invoice for CM Order #[${courseMerchantOrderId}]`);
                try {
                    const invoice = record.transform({
                        fromType: record.Type.SALES_ORDER,
                        fromId: salesOrder.id,
                        toType: record.Type.INVOICE
                    });
                    const salesOrderDate = salesOrder.getValue('trandate');
                    invoice.setValue('trandate', salesOrderDate);
                    const invoiceId = invoice.save({ignoreMandatoryFields: true});
                    transactionsCreated.invoice = {id: invoiceId};
                } catch (error) {
                    const errorDetails = 'Failure creating Invoice for CM Order ' + courseMerchantOrderId + '. Details: ' + JSON.stringify(error);
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler', errorDetails);
                }
            }
            
            const _createCustomerPayment = () => {
                log.audit('CourseMerchantOrderHandler', `Creating Payment for CM Order #[${courseMerchantOrderId}]`);
                try {
                    const customerPayment = _initializeCustomerPayment();
                    const paymentId = customerPayment.save({ignoreMandatoryFields: true});
                    transactionsCreated.payment = { id: paymentId };
                } catch(error){
                    const errorDetails = 'Failure creating Customer Payment for CM Order ' + courseMerchantOrderId + '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _createCustomerPaymentWithCreditAndNewInvoiceApplied = () => {
                log.audit('CourseMerchantOrderHandler', `Creating Payment for CM Order #[${courseMerchantOrderId}]`);
                try {
                    const customerPayment = _initializeCustomerPayment();
                    _applyCreditToPayment(customerPayment);
                    const paymentId = customerPayment.save({ignoreMandatoryFields: true});
                    transactionsCreated.payment = { id: paymentId };
                } catch(error){
                    const errorDetails = 'Failure creating Customer Payment for CM Order ' + courseMerchantOrderId + '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _applyCreditToPayment = (customerPayment) => {
                for(let i = 0; i < customerPayment.getLineCount('credit'); i++){
                    const creditMemoId = customerPayment.getSublistValue({sublistId: 'credit', fieldId: 'internalid', line: i});
                    if(creditMemoId == transactionsCreated.creditMemo.id){
                        customerPayment.setSublistValue({sublistId: 'credit', fieldId: 'apply', value: true, line: i});
                    }
                }
            }
            
            const _initializeCustomerPayment = () => {
                const customerPayment = record.transform({
                    fromType: record.Type.INVOICE,
                    fromId: transactionsCreated.invoice.id,
                    toType: record.Type.CUSTOMER_PAYMENT
                });
                customerPayment.setValue('paymentmethod', salesOrder.getValue('custbody_cdg_cm_payment_method'));
                customerPayment.setValue('trandate', salesOrder.getValue('trandate'));
                customerPayment.setValue('custbody_cdg_source_system', salesOrder.getValue('custbody_cdg_source_system'));
                customerPayment.setValue('custbody_cdg_cm_customer_name', salesOrder.getValue('custbody_cdg_cm_customer_name'));
                customerPayment.setValue('custbody_cdg_cm_customer_contact', salesOrder.getValue('custbody_cdg_cm_customer_contact'));
                customerPayment.setValue('custbody_cdg_cm_order_id', salesOrder.getValue('custbody_cdg_cm_order_id'));
                customerPayment.setValue('custbody_cdg_cm_order_original_id', salesOrder.getValue('custbody_cdg_cm_order_original_id'));
                customerPayment.setValue('custbody_cdg_cm_payment_reference_no', salesOrder.getValue('custbody_cdg_cm_payment_reference_no'));
                return customerPayment;
            }
            
            const _cancelSalesOrder = () => {
                const newSalesOrder = record.load({type: record.Type.SALES_ORDER, id: salesOrder.id});
                try {
                    _cancelSalesOrderItems(newSalesOrder);
                    newSalesOrder.save({ignoreMandatoryFields: true});
                } catch(error){
                    const errorDetails = 'Failure Closing CM Order ' + courseMerchantOrderId + '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _cancelSalesOrderItems = (newSalesOrder) => {
                for(let i = 0; i < newSalesOrder.getLineCount('item'); i++){
                    newSalesOrder.setSublistValue({sublistId: 'item', fieldId: 'isclosed', value: true, line: i});
                }
            }
            
            const _isOrderAmendment = () => {
                return originalCourseMerchantOrderId;
            }
            
            const _customerPaymentIsRequired = () => {
                const noneInvoicePaymentMethod = runtime.getCurrentScript().getParameter('custscript_cdg_none_invoice_pay_method'),
                    freePaymentMethod = runtime.getCurrentScript().getParameter('custscript_cdg_none_free_pay_method'),
                    courseMerchantPaymentMethod = salesOrder.getValue('custbody_cdg_cm_payment_method');
                return courseMerchantPaymentMethod &&
                    courseMerchantPaymentMethod != noneInvoicePaymentMethod && courseMerchantPaymentMethod != freePaymentMethod;
            }
            
            const _isCancelationOrder = () => {
                return salesOrder.getValue('total') == 0;
            }
            
            const _searchOriginalOrderInvoiceId = (originalSalesOrderInternalId) => {
                let originalOrderInvoiceId = '';
                search.create({
                    type: search.Type.INVOICE,
                    filters: ['createdfrom', 'is', originalSalesOrderInternalId],
                    columns: []
                }).run().each(result => {
                    originalOrderInvoiceId = result.id;
                })
                return originalOrderInvoiceId;
            }
            
            const _createReturnAuthorization = (invoiceId) => {
                log.audit('CourseMerchantOrderHandler', 'Creating RMA for Original SalesOrder/Invoice with ' +
                    'CM id [ ' + originalCourseMerchantOrderId + ' ]');
                
                try {
                    const returnAuthorization = record.transform({
                        fromType: record.Type.INVOICE,
                        fromId: invoiceId,
                        toType: record.Type.RETURN_AUTHORIZATION
                    });
                    returnAuthorization.setValue('trandate', salesOrder.getValue('trandate'));
    
                    const returnAuthorizationId = returnAuthorization.save({ignoreMandatoryFields: true});
                    transactionsCreated.returnAuthorization = {id: returnAuthorizationId};
                } catch(error){
                    const errorDetails = 'Failure creating Return Authorization for CM SalesOrder ' + originalCourseMerchantOrderId +
                        '. Details: ' + JSON.stringify(error);
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _createCreditMemo = () => {
                log.audit('CourseMerchantOrderHandler', `Creating Credit Memo for CM SalesOrder #[${originalCourseMerchantOrderId}]`);
                try {
                    const creditMemo = _initializeCreditMemo();
                    const creditMemoId = creditMemo.save({ignoreMandatoryFields: true});
                    transactionsCreated.creditMemo = {id: creditMemoId};
                } catch(error){
                     const errorDetails = 'Failure creating Credit Memo for CM SalesOrder ' + originalCourseMerchantOrderId +
                         '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _createCreditMemoWithOriginalInvoiceApplied = (originalInvoiceId) => {
                log.audit('CourseMerchantOrderHandler', `Creating Credit Memo for CM SalesOrder #[${originalCourseMerchantOrderId}]`);
                try {
                    const creditMemo = _initializeCreditMemo();
                    _applyCreditToInvoice(creditMemo, originalInvoiceId);
                    const creditMemoId = creditMemo.save({ignoreMandatoryFields: true});
                    transactionsCreated.creditMemo = {id: creditMemoId};
                } catch(error){
                     const errorDetails = 'Failure creating Credit Memo for CM SalesOrder ' + originalCourseMerchantOrderId +
                         '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _createCreditMemoWithNewInvoiceApplied = () => {
                log.audit('CourseMerchantOrderHandler', `Creating Credit Memo for CM SalesOrder #[${originalCourseMerchantOrderId}]`);
                try {
                    const creditMemo = _initializeCreditMemo();
                    _applyCreditToInvoice(creditMemo, transactionsCreated.invoice.id);
                    const creditMemoId = creditMemo.save({ignoreMandatoryFields: true});
                    transactionsCreated.creditMemo = {id: creditMemoId};
                } catch(error){
                     const errorDetails = 'Failure creating Credit Memo for CM SalesOrder ' + originalCourseMerchantOrderId +
                         '. Details: ' + JSON.stringify(error)
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.Error', errorDetails);
                }
            }
            
            const _applyCreditToInvoice = (creditMemo, originalInvoiceId) => {
                for(let i = 0; i < creditMemo.getLineCount('apply'); i++){
                    const invoiceId = creditMemo.getSublistValue({sublistId: 'apply', fieldId: 'internalid', line: i});
                    if(invoiceId == originalInvoiceId){
                        creditMemo.setSublistValue({sublistId: 'apply', fieldId: 'apply', value: true, line: i});
                    }
                }
            }
            
            const _initializeCreditMemo = () => {
                const creditMemo = record.transform({
                    fromType: record.Type.RETURN_AUTHORIZATION,
                    fromId: transactionsCreated.returnAuthorization.id,
                    toType: record.Type.CREDIT_MEMO
                });
                creditMemo.setValue('trandate', salesOrder.getValue('trandate'));
                return creditMemo;
            }
            
            const _errorOutOriginalSalesOrderIdNotFound = () => {
                const errorDetails = 'Could Not Find Original SalesOrder [' + originalCourseMerchantOrderId + '].';
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.error', errorDetails);
            }
            
            const _errorOutOriginalInvoiceIdNotFound = () => {
                const errorDetails = 'Could Not Find Invoice for CM Original SalesOrder [' + originalCourseMerchantOrderId + '].'
                    _turnOffFurtherProcessing(errorDetails);
                    log.error('CourseMerchantOrderHandler.error', errorDetails);
            }
            
            const _turnOffFurtherProcessing = (errorDetails) => {
                keepProcessingTransactions = false;
                processingErrors.push(errorDetails);
            }
            
            const _maybePushOutErrors = () => {
                if(processingErrors.length > 0){
                    let joinedErrors = '';
                    processingErrors.forEach((error, index) => {
                        joinedErrors += index + 1 + '. ' + error + '\r\n';
                    })
                    let errorDetails = 'Could not Fully Process SalesOrder. ErrorDetails: \r\n' +
                        joinedErrors + '. Here is the List of Transactions that we\'ve managed to Create: \r\n' +
                        JSON.stringify(transactionsCreated);
                    throw new Error(errorDetails);
                }
            }
            
            const _getOriginalSalesOrderInternalId = () => {
                const topOfSalesOrderAmendmentsId = _searchTopOfSalesOrderAmendments();
                if(topOfSalesOrderAmendmentsId){
                    return topOfSalesOrderAmendmentsId;
                } else{
                    return _searchOriginalSalesOrderInternalId();
                }
            }
            
            const _searchTopOfSalesOrderAmendments = () => {
                let previousAmendmentSalesOrderId = '';
                search.create({
                    type: search.Type.SALES_ORDER,
                    filters: [
                        ['internalid', 'noneof', salesOrder.id], 'AND',
                        ['custbody_cdg_cm_order_original_id', 'is', originalCourseMerchantOrderId]
                    ],
                    columns: [
                        {name: 'internalid', sort: search.Sort.DESC}
                    ]
                }).run().each(result => {
                    previousAmendmentSalesOrderId = result.id;
                })
                return previousAmendmentSalesOrderId;
            }
            
            const _searchOriginalSalesOrderInternalId = () => {
                let originalSalesOrderInternalId = '';
                search.create({
                    type: search.Type.SALES_ORDER,
                    filters: [
                        ['custbody_cdg_cm_order_id', 'is', originalCourseMerchantOrderId]
                    ],
                    columns: []
                }).run().each(result => {
                    originalSalesOrderInternalId = result.id;
                })
                return originalSalesOrderInternalId;
            }
            
            const _originalInvoiceShouldBeClosed = (originalInvoiceId) => {
                const lookUpResult = search.lookupFields({
                    type: search.Type.INVOICE,
                    id: originalInvoiceId,
                    columns: ['status']
                });
                const invoiceStatus = lookUpResult['status'][0].value;
                return invoiceStatus === 'open';
            }
            
            return {handle}
        }
        
        return {handle};
    });